from flask import Blueprint, render_template, request, redirect, url_for, flash, session, g
from werkzeug.security import generate_password_hash
from db import get_conn, list_devices, get_setting, set_setting
from authz import login_required, role_required
import sqlite3, re, unicodedata, secrets


def _slug(s):
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]", "", s.lower())


def _gen_username(conn, name, employee_id):
    """Friendly, unique username: first initial + first (paternal) surname.
    For Mexican names with two surnames (given … paternal maternal) this uses
    the paternal surname (second-to-last word): 'Andrea Damaris Martínez Rivas'
    -> 'amartinez'. Two-word names use the single surname; else the employee id."""
    parts = [p for p in (name or "").split() if p]
    if len(parts) >= 3:
        base = _slug(parts[0][0] + parts[-2])   # first initial + paternal surname
    elif len(parts) == 2:
        base = _slug(parts[0][0] + parts[1])
    elif parts:
        base = _slug(parts[0])
    else:
        base = ""
    if not base:
        base = f"emp{employee_id}"
    existing = {r[0] for r in conn.execute("SELECT username FROM accounts").fetchall()}
    cand, i = base, 1
    while cand in existing:
        i += 1
        cand = f"{base}{i}"
    return cand


def _create_login_for(conn, emp, role, default_pw):
    """Create a login account linked to an employee. Returns (username, 'ok')
    or (None, 'exists'). Name/email are mirrored from the employee (single
    source of truth); the account must change its password on first sign-in."""
    if conn.execute("SELECT id FROM accounts WHERE employee_id=?",
                    (emp["employee_id"],)).fetchone():
        return (None, "exists")
    username = _gen_username(conn, emp["name"], emp["employee_id"])
    pw = default_pw or secrets.token_urlsafe(6)
    conn.execute(
        "INSERT INTO accounts (username, password_hash, role, employee_id, active, "
        "full_name, email, email_verified, must_change_password, created_at) "
        "VALUES (?,?,?,?,1,?,?,0,1,datetime('now'))",
        (username, generate_password_hash(pw), role, emp["employee_id"],
         emp["name"], (emp["email"] or None)))
    return (username, "ok")


def _norm_name(s):
    s = unicodedata.normalize("NFKD", (s or "")).encode("ascii", "ignore").decode().lower()
    return " ".join(s.split())


def _match_unlinked_employee(conn, name, email):
    """Find an existing ACTIVE employee that has no login yet, matching by email
    (exact, case-insensitive) or by normalized full name. Returns employee_id or
    None. Used so a new account links to an existing person instead of creating
    a duplicate employee record."""
    rows = conn.execute(
        "SELECT u.employee_id, u.name, u.email FROM users u "
        "LEFT JOIN accounts a ON a.employee_id=u.employee_id "
        "WHERE u.is_active=1 AND a.id IS NULL").fetchall()
    em = (email or "").strip().lower()
    if em:
        for r in rows:
            if (r["email"] or "").strip().lower() == em:
                return r["employee_id"]
    nn = _norm_name(name)
    if nn:
        for r in rows:
            if _norm_name(r["name"]) == nn:
                return r["employee_id"]
    return None


def _employee_duplicate(conn, name, email, exclude_id=None):
    """Return an existing active employee (row) that looks like a duplicate of
    the given name/email, or None. Matches exact email or normalized name."""
    rows = conn.execute(
        "SELECT employee_id, name, email FROM users WHERE is_active=1").fetchall()
    em = (email or "").strip().lower()
    nn = _norm_name(name)
    for r in rows:
        if exclude_id and str(r["employee_id"]) == str(exclude_id):
            continue
        if em and (r["email"] or "").strip().lower() == em:
            return r
        if nn and _norm_name(r["name"]) == nn:
            return r
    return None

# ─── USERS ───────────────────────────────────────────────────────────────────

bp_users = Blueprint("users", __name__, url_prefix="/users")

@bp_users.route("/")
@login_required
@role_required("admin", "manager")
def users_list():
    show_inactive = request.args.get("show_inactive") == "1"
    conn = get_conn()
    where = "" if show_inactive else "WHERE u.is_active=1"
    rows = conn.execute(f"""
        SELECT u.employee_id, u.name, u.is_active, u.archived,
               COALESCE(d.name,'—') as dept,
               COUNT(DISTINCT uf.id) as face_count,
               u.email as email,
               a.id as account_id, a.username as username,
               a.role as account_role, a.active as account_active
        FROM users u
        LEFT JOIN departments d ON d.id=u.department_id
        LEFT JOIN user_faces uf ON uf.employee_id=u.employee_id
        LEFT JOIN accounts a ON a.employee_id=u.employee_id
        {where} {'' if session.get('role')=='admin' else 'AND COALESCE(d.hidden,0)=0'}
        GROUP BY u.employee_id
        ORDER BY CASE WHEN CAST(u.employee_id AS INTEGER)>0
                 THEN CAST(u.employee_id AS INTEGER) ELSE 999999 END
    """).fetchall()
    conn.close()
    no_login = sum(1 for r in rows if r["is_active"] and not r["account_id"])
    is_admin = session.get("role") == "admin"
    return render_template("users.html", users=rows, show_inactive=show_inactive,
                           no_login=no_login, is_admin=is_admin,
                           default_pw=_default_password())

@bp_users.route("/create-login/<employee_id>", methods=["POST"])
@login_required
@role_required("admin")
def users_create_login(employee_id):
    role = request.form.get("role", "employee")
    if role not in ("employee", "foreman", "viewer", "manager", "admin"):
        role = "employee"
    default_pw = _default_password()
    conn = get_conn()
    emp = conn.execute("SELECT employee_id, name, email FROM users WHERE employee_id=?",
                       (employee_id,)).fetchone()
    if not emp:
        conn.close()
        return redirect(url_for("users.users_list"))
    uname, res = _create_login_for(conn, emp, role, default_pw)
    conn.commit()
    conn.close()
    if res == "exists":
        flash(f"{emp['name']} already has a login.", "warning")
    else:
        extra = "" if default_pw else " (a random temporary password was set — use Send login or Reset)"
        flash(f"Login created for {emp['name']}: username “{uname}”.{extra} "
              f"Use Send login on the Accounts page to deliver it.", "success")
    return redirect(url_for("users.users_list"))

@bp_users.route("/create-login-all", methods=["POST"])
@login_required
@role_required("admin")
def users_create_login_all():
    default_pw = _default_password()
    conn = get_conn()
    emps = conn.execute(
        "SELECT u.employee_id, u.name, u.email FROM users u "
        "LEFT JOIN accounts a ON a.employee_id=u.employee_id "
        "WHERE u.is_active=1 AND a.id IS NULL "
        "ORDER BY CAST(u.employee_id AS INTEGER)").fetchall()
    made = 0
    for emp in emps:
        _u, res = _create_login_for(conn, emp, "employee", default_pw)
        if res == "ok":
            made += 1
    conn.commit()
    conn.close()
    tail = ("" if default_pw else
            " No default password is set, so each got a random temporary one — "
            "set a default and use Reset/Send login, or the login sheet.")
    flash(f"Created {made} login(s) for employees without one.{tail} "
          f"Go to Accounts to email them or print the login sheet.", "success")
    return redirect(url_for("users.users_list"))

@bp_users.route("/add", methods=["GET", "POST"])
@login_required
@role_required("admin")
def users_add():
    conn = get_conn()
    if request.method == "POST":
        emp_id = request.form.get("employee_id", "").strip()
        first_name = (request.form.get("first_name") or "").strip()
        last_name  = (request.form.get("last_name") or "").strip()
        name   = (first_name + " " + last_name).strip() or (request.form.get("name") or "").strip()
        dept   = request.form.get("department_id") or None
        if not emp_id or not name:
            flash("Employee ID and name are required", "danger")
        elif (lambda d: d and request.form.get("confirm") != "1")(_employee_duplicate(conn, name, None)):
            dup = _employee_duplicate(conn, name, None)
            depts = conn.execute("SELECT id, name FROM departments ORDER BY name").fetchall()
            conn.close()
            return render_template("users_add.html", next_id=emp_id, depts=depts,
                                   devices=list_devices(), dup=dup,
                                   first_name=first_name, last_name=last_name, sel_dept=dept)
        else:
            try:
                conn.execute(
                    "INSERT INTO users (employee_id, name, is_active, department_id) VALUES (?,?,1,?)",
                    (emp_id, name, dept))
                conn.commit()
                conn.close()
                # Optional face photo captured at creation time: save it as the
                # enrolled face and push to the terminals immediately.
                f = request.files.get("face_photo")
                if f and f.filename:
                    try:
                        from services.face_sync import store_face_bytes
                        from routes.faces import _push_face_to_devices
                        data = f.read()
                        if store_face_bytes(emp_id, data):
                            try:
                                _push_face_to_devices(emp_id, data)
                                flash("User added with face photo (pushed to devices)", "success")
                            except Exception:
                                flash("User added with face photo (device push pending)", "success")
                        else:
                            flash("User added, but the photo was not a valid image", "warning")
                    except Exception as e:
                        flash(f"User added; photo failed: {e}", "warning")
                else:
                    flash("User added", "success")
                return redirect(url_for("users.users_list"))
            except sqlite3.IntegrityError:
                flash("Employee ID already exists", "danger")

    next_id = (conn.execute("SELECT MAX(CAST(employee_id AS INTEGER)) FROM users").fetchone()[0] or 0) + 1
    depts   = conn.execute("SELECT id, name FROM departments ORDER BY name").fetchall()
    conn.close()
    return render_template("users_add.html", next_id=next_id, depts=depts, devices=list_devices())

@bp_users.route("/edit/<emp_id>", methods=["GET", "POST"])
@login_required
@role_required("admin")
def users_edit(emp_id):
    conn = get_conn()
    if request.method == "POST":
        req_prod = 1 if request.form.get("requires_production") else 0
        first_name = (request.form.get("first_name") or "").strip()
        last_name  = (request.form.get("last_name") or "").strip()
        # Fall back to a legacy single "name" field if present.
        name = (first_name + " " + last_name).strip() or (request.form.get("name") or "").strip()
        email_in = (request.form.get("email") or "").strip() or None
        conn.execute(
            "UPDATE users SET name=?, department_id=?, requires_production=?, "
            "email=?, phone=?, hire_date=?, position=?, default_site_id=? WHERE employee_id=?",
            (name, request.form.get("department_id") or None, req_prod,
             email_in,
             (request.form.get("phone") or "").strip() or None,
             (request.form.get("hire_date") or "").strip() or None,
             (request.form.get("position") or "").strip() or None,
             (request.form.get("default_site_id") or None),
             emp_id))
        # Two-way sync: push the shared fields (name, email, role) to the
        # linked account so editing in either place keeps them identical.
        acct = conn.execute(
            "SELECT id, role FROM accounts WHERE employee_id=? LIMIT 1", (emp_id,)).fetchone()
        if acct:
            conn.execute("UPDATE accounts SET full_name=? WHERE employee_id=?", (name, emp_id))
            if email_in:
                conn.execute("UPDATE accounts SET email=? WHERE employee_id=?", (email_in, emp_id))
            new_role = request.form.get("account_role")
            if new_role in ("admin", "manager", "viewer", "employee", "foreman"):
                # Don't let an admin strip their own admin role from here.
                if not (session.get("account_id") == acct["id"] and new_role != "admin"):
                    conn.execute("UPDATE accounts SET role=? WHERE employee_id=?", (new_role, emp_id))
        # Schedule assignment lives in user_schedule_assignments (what the
        # lateness calc reads). Empty value clears it.
        tmpl = request.form.get("template_id") or ""
        conn.execute("DELETE FROM user_schedule_assignments WHERE employee_id=?", (emp_id,))
        if tmpl:
            conn.execute(
                "INSERT OR REPLACE INTO user_schedule_assignments (employee_id, template_id) VALUES (?,?)",
                (emp_id, int(tmpl)))
        conn.commit()
        conn.close()
        flash("User updated", "success")
        return redirect(url_for("users.users_list"))
    user  = conn.execute("SELECT * FROM users WHERE employee_id=?", (emp_id,)).fetchone()
    depts = conn.execute("SELECT id, name FROM departments ORDER BY name").fetchall()
    templates = conn.execute("SELECT id, name FROM schedule_templates ORDER BY name").fetchall()
    sites = conn.execute("SELECT id, name FROM gps_sites WHERE active=1 ORDER BY name").fetchall()
    # Pull the linked account's email so the employee email field auto-populates
    # when the employee's own copy is still empty (avoids duplicate/blank data).
    linked = conn.execute(
        "SELECT id, email, full_name, role, username FROM accounts WHERE employee_id=? LIMIT 1",
        (emp_id,)).fetchone()
    cur_tmpl = conn.execute(
        "SELECT template_id FROM user_schedule_assignments WHERE employee_id=?", (emp_id,)).fetchone()
    cur_tmpl_id = cur_tmpl["template_id"] if cur_tmpl else None
    conn.close()
    if not user:
        flash("User not found", "danger")
        return redirect(url_for("users.users_list"))
    # Best-effort split of the stored full name into first / rest for editing.
    _nm = (user["name"] or "").strip()
    _parts = _nm.split(" ", 1)
    first_name = _parts[0] if _parts and _parts[0] else ""
    last_name  = _parts[1] if len(_parts) > 1 else ""
    # Effective email: the employee's own, else the linked account's.
    email_value = (user["email"] or (linked["email"] if linked else "") or "")
    return render_template("users_edit.html", user=user, depts=depts,
                           first_name=first_name, last_name=last_name,
                           templates=templates, cur_tmpl_id=cur_tmpl_id,
                           sites=sites, cur_site_id=user["default_site_id"],
                           email_value=email_value, linked=linked)

@bp_users.route("/toggle/<emp_id>", methods=["POST"])
@login_required
@role_required("admin")
def users_toggle(emp_id):
    conn = get_conn()
    # Reactivating also clears the archived flag (brings them back on the roster).
    conn.execute(
        "UPDATE users SET is_active=CASE WHEN is_active=1 THEN 0 ELSE 1 END, "
        "archived=CASE WHEN is_active=1 THEN archived ELSE 0 END WHERE employee_id=?",
        (emp_id,))
    conn.commit()
    conn.close()
    return redirect(url_for("users.users_list"))

@bp_users.route("/delete/<emp_id>", methods=["POST"])
@login_required
@role_required("admin")
def users_delete(emp_id):
    conn = get_conn()
    # How many attendance records does this person have? If any, we must NOT
    # destroy them (legal retention) — we archive the employee instead.
    ev_count = conn.execute(
        "SELECT COUNT(*) FROM events WHERE employee_id=?", (emp_id,)).fetchone()[0]

    # Either way, remove the biometric enrolment: the person is no longer an
    # active employee, so their face comes off the terminals and local storage.
    conn.execute("DELETE FROM user_faces WHERE employee_id=?", (emp_id,))
    # Disable any linked login so they can't sign in.
    conn.execute("UPDATE accounts SET active=0 WHERE employee_id=?", (emp_id,))

    if ev_count > 0:
        # Keep the employee record AND their events; just archive them.
        conn.execute(
            "UPDATE users SET is_active=0, archived=1 WHERE employee_id=?", (emp_id,))
        msg = (f"Employee archived — {ev_count} attendance record(s) kept on file. "
               f"Their face was removed from the terminals.")
    else:
        # No attendance history exists, so it is safe to remove entirely
        # (useful for test entries or duplicates created by mistake).
        conn.execute("DELETE FROM users WHERE employee_id=?", (emp_id,))
        conn.execute("DELETE FROM accounts WHERE employee_id=? AND LOWER(role)!='admin'", (emp_id,))
        msg = "Employee removed (no attendance records existed)."

    conn.commit()
    conn.close()
    import os
    face_path = f"/var/lib/attendance/faces/{emp_id}.jpg"
    if os.path.exists(face_path):
        os.remove(face_path)
    try:
        import requests as _requests
        from requests.auth import HTTPDigestAuth as _Digit
        from db import get_conn as _get_conn
        dconn = _get_conn()
        devices = dconn.execute("SELECT ip, username, password FROM devices WHERE active=1").fetchall()
        dconn.close()
        for d in devices:
            auth = _Digit(d["username"], d["password"])
            _requests.delete(f"http://{d['ip']}/ISAPI/Intelligent/FDLib/FDSetUp?format=json",
                json={"FDID": "1", "FPID": emp_id, "faceLibType": "blackFD"},
                auth=auth, timeout=10, verify=False)
            _requests.put(f"http://{d['ip']}/ISAPI/AccessControl/UserInfo/Delete?format=json",
                json={"UserInfoDelCond": {"EmployeeNoList": [{"employeeNo": emp_id}]}},
                auth=auth, timeout=10, verify=False)
    except Exception as e:
        log.warning(f"Device cleanup failed for {emp_id}: {e}")
    flash(msg, "success")
    return redirect(url_for("users.users_list"))

# ─── DEPARTMENTS ─────────────────────────────────────────────────────────────
bp_depts = Blueprint("departments", __name__, url_prefix="/departments")

@bp_depts.route("/")
@login_required
@role_required("admin")
def list_departments():
    conn = get_conn()
    depts = conn.execute("""
        SELECT d.id, d.name, COUNT(u.employee_id) as user_count
        FROM departments d
        LEFT JOIN users u ON u.department_id=d.id
        GROUP BY d.id ORDER BY d.name
    """).fetchall()
    conn.close()
    return render_template("departments.html", departments=depts)

@bp_depts.route("/create", methods=["POST"])
@login_required
@role_required("admin")
def create_department():
    name = (request.form.get("name") or "").strip()
    if not name:
        flash("Name required", "warning")
        return redirect(url_for("departments.list_departments"))
    conn = get_conn()
    try:
        conn.execute("INSERT INTO departments (name) VALUES (?)", (name,))
        conn.commit()
        flash("Department created", "success")
    except Exception as e:
        flash(f"Error: {e}", "danger")
    finally:
        conn.close()
    return redirect(url_for("departments.list_departments"))

@bp_depts.route("/delete/<int:dept_id>", methods=["POST"])
@login_required
@role_required("admin")
def delete_department(dept_id):
    conn = get_conn()
    count = conn.execute("SELECT COUNT(*) FROM users WHERE department_id=?", (dept_id,)).fetchone()[0]
    if count:
        conn.close()
        flash("Cannot delete: users are assigned to this department", "warning")
        return redirect(url_for("departments.list_departments"))
    conn.execute("DELETE FROM departments WHERE id=?", (dept_id,))
    conn.commit()
    conn.close()
    flash("Department deleted", "success")
    return redirect(url_for("departments.list_departments"))

@bp_depts.route("/edit/<int:dept_id>", methods=["POST"])
@login_required
@role_required("admin")
def edit_department(dept_id):
    name = (request.form.get("name") or "").strip()
    if name:
        conn = get_conn()
        conn.execute("UPDATE departments SET name=? WHERE id=?", (name, dept_id))
        conn.commit()
        conn.close()
        flash("Department updated", "success")
    return redirect(url_for("departments.list_departments"))

# ─── ACCOUNTS ────────────────────────────────────────────────────────────────

bp_accounts = Blueprint("accounts", __name__, url_prefix="/accounts")

@bp_accounts.route("/")
@login_required
@role_required("admin")
def accounts_list():
    conn = get_conn()
    # Pending (inactive) accounts first, so approvals are front and centre.
    rows = conn.execute(
        "SELECT id, username, role, employee_id, active, email, "
        "       email_verified, created_at, full_name "
        "FROM accounts ORDER BY active ASC, created_at DESC, username"
    ).fetchall()
    conn.close()
    pending = sum(1 for r in rows if not r["active"])
    return render_template("accounts.html", accounts=rows, pending=pending,
                           default_pw=_default_password())

@bp_accounts.route("/create", methods=["POST"])
@login_required
@role_required("admin")
def accounts_create():
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    role     = request.form.get("role")
    first_name = (request.form.get("first_name") or "").strip()
    last_name  = (request.form.get("last_name") or "").strip()
    full_name  = (first_name + " " + last_name).strip()
    employee_id = (request.form.get("employee_id") or "").strip() or None
    if not username or not password or role not in ("admin", "manager", "viewer", "employee", "foreman"):
        flash("Invalid input", "danger")
        return redirect(url_for("accounts.accounts_list"))
    conn = get_conn()
    try:
        cur = conn.execute(
            "INSERT INTO accounts (username, password_hash, role, employee_id, active, full_name, email_verified) "
            "VALUES (?,?,?,?,1,?,1)",
            (username, generate_password_hash(password), role, employee_id, full_name or None))
        account_id = cur.lastrowid

        # Employee/foreman accounts represent attendance-tracked people. If one
        # isn't linked to an existing employee, create the employee record so it
        # shows up in Users (same behavior as approving a registration).
        linked_note = ""
        if role in ("employee", "foreman") and not employee_id:
            name = full_name or username
            match = _match_unlinked_employee(conn, full_name, None)
            if match:
                conn.execute("UPDATE accounts SET employee_id=? WHERE id=?", (match, account_id))
                linked_note = f" (linked to existing employee #{match})"
            else:
                new_emp = str((conn.execute(
                    "SELECT MAX(CAST(employee_id AS INTEGER)) FROM users").fetchone()[0] or 0) + 1)
                conn.execute("INSERT INTO users (employee_id, name, is_active) VALUES (?,?,1)",
                             (new_emp, name))
                conn.execute("UPDATE accounts SET employee_id=? WHERE id=?", (new_emp, account_id))

        conn.commit()
        flash("Account created" + linked_note, "success")
    except sqlite3.IntegrityError:
        flash("Username already exists", "danger")
    finally:
        conn.close()
    return redirect(url_for("accounts.accounts_list"))

@bp_accounts.route("/reset/<int:account_id>", methods=["POST"])
@login_required
@role_required("admin")
def accounts_reset(account_id):
    pw = request.form.get("password", "")
    if not pw:
        flash("Password required", "danger")
        return redirect(url_for("accounts.accounts_list"))
    conn = get_conn()
    conn.execute("UPDATE accounts SET password_hash=? WHERE id=?",
                 (generate_password_hash(pw), account_id))
    conn.commit()
    conn.close()
    flash("Password reset", "success")
    return redirect(url_for("accounts.accounts_list"))

# ─── Credential distribution ────────────────────────────────────────────────

def _site_base() -> str:
    """Public base URL for the login link in emails."""
    base = (get_setting("site_url", "") or "").strip().rstrip("/")
    if base:
        return base
    host = request.headers.get("X-Forwarded-Host") or request.host
    return f"https://{host}"

def _default_password() -> str:
    return (get_setting("default_user_password", "") or "").strip()

def _apply_default_and_email(conn, acct, default_pw, base_url):
    """Reset one account to the default password and flag change-on-first-login.
    Email the credentials when the account has an address.
    Returns 'emailed' | 'no_email' | 'error'."""
    conn.execute("UPDATE accounts SET password_hash=?, must_change_password=1 WHERE id=?",
                 (generate_password_hash(default_pw), acct["id"]))
    email = (acct["email"] or "").strip()
    if not email:
        return "no_email"
    try:
        from services.mailer import send_email, build_branded_email
        T = getattr(g, "T", {}) or {}
        def _t(k, f): return (T.get(k, f) if hasattr(T, "get") else f)
        name = acct["full_name"] or acct["username"]
        html, text, inline = build_branded_email(
            heading=_t("email_login_heading", "Your login details"),
            paragraphs=[
                _t("email_login_p1", "Hello {name}, an account has been created for you.").replace("{name}", name),
                _t("email_login_user", "Username: <b>{u}</b>").replace("{u}", acct["username"]),
                _t("email_login_pass", "Temporary password: <b>{p}</b>").replace("{p}", default_pw),
                _t("email_login_p2", "You'll be asked to choose your own password the first time you sign in."),
            ],
            cta_label=_t("email_login_cta", "Sign in"),
            cta_url=f"{base_url}{url_for('auth.login')}",
            footer=_t("email_login_footer", "If you weren't expecting this, contact your administrator."),
        )
        ok, _err = send_email(email, _t("email_login_subject", "Your login details"),
                              html, text, inline_images=inline)
        return "emailed" if ok else "error"
    except Exception:
        return "error"

@bp_accounts.route("/default-password", methods=["POST"])
@login_required
@role_required("admin")
def accounts_default_pw():
    pw = (request.form.get("default_password") or "").strip()
    if len(pw) < 6:
        flash("Default password must be at least 6 characters.", "danger")
    else:
        set_setting("default_user_password", pw)
        flash("Default password saved.", "success")
    return redirect(url_for("accounts.accounts_list"))

@bp_accounts.route("/send-login/<int:account_id>", methods=["POST"])
@login_required
@role_required("admin")
def accounts_send_login(account_id):
    default_pw = _default_password()
    if len(default_pw) < 6:
        flash("Set a default password first (at least 6 characters).", "danger")
        return redirect(url_for("accounts.accounts_list"))
    base = _site_base()
    conn = get_conn()
    acct = conn.execute(
        "SELECT id, username, full_name, email FROM accounts WHERE id=?",
        (account_id,)).fetchone()
    if not acct:
        conn.close()
        return redirect(url_for("accounts.accounts_list"))
    res = _apply_default_and_email(conn, acct, default_pw, base)
    conn.commit()
    conn.close()
    if res == "emailed":
        flash(f"Login details emailed to {acct['username']}.", "success")
    elif res == "no_email":
        flash(f"{acct['username']} has no email on file — password set to the default. "
              f"Use the login sheet to hand it out.", "warning")
    else:
        flash(f"Password set to the default for {acct['username']}, but the email "
              f"could not be sent — check SMTP settings.", "warning")
    return redirect(url_for("accounts.accounts_list"))

@bp_accounts.route("/send-login-all", methods=["POST"])
@login_required
@role_required("admin")
def accounts_send_login_all():
    default_pw = _default_password()
    if len(default_pw) < 6:
        flash("Set a default password first (at least 6 characters).", "danger")
        return redirect(url_for("accounts.accounts_list"))
    base = _site_base()
    me = session.get("account_id")
    conn = get_conn()
    rows = conn.execute(
        "SELECT id, username, full_name, email FROM accounts "
        "WHERE active=1 AND role != 'admin' AND id != ?", (me,)).fetchall()
    emailed = no_email = errors = 0
    for acct in rows:
        r = _apply_default_and_email(conn, acct, default_pw, base)
        if r == "emailed":   emailed += 1
        elif r == "no_email": no_email += 1
        else:                 errors += 1
    conn.commit()
    conn.close()
    flash(f"Default password applied to {len(rows)} account(s): {emailed} emailed, "
          f"{no_email} without email (use the login sheet), {errors} email error(s).", "success")
    return redirect(url_for("accounts.accounts_list"))

@bp_accounts.route("/login-sheet")
@login_required
@role_required("admin")
def accounts_login_sheet():
    default_pw = _default_password()
    conn = get_conn()
    rows = conn.execute(
        "SELECT username, full_name, role, email, employee_id FROM accounts "
        "WHERE active=1 AND must_change_password=1 "
        "ORDER BY CAST(employee_id AS INTEGER), username").fetchall()
    conn.close()
    company = get_setting("company_name", "") or "Attendance"
    return render_template("login_sheet.html", rows=rows, default_pw=default_pw,
                           company=company, T=getattr(g, "T", {}))

@bp_accounts.route("/toggle/<int:account_id>", methods=["POST"])
@login_required
@role_required("admin")
def accounts_toggle(account_id):
    if session.get("account_id") == account_id:
        flash("Cannot deactivate your own account", "danger")
        return redirect(url_for("accounts.accounts_list"))
    conn = get_conn()
    acct = conn.execute(
        "SELECT active, employee_id, full_name, username, email FROM accounts WHERE id=?",
        (account_id,)).fetchone()
    if not acct:
        conn.close()
        return redirect(url_for("accounts.accounts_list"))

    becoming_active = not acct["active"]
    conn.execute(
        "UPDATE accounts SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=?",
        (account_id,))

    # On approval (inactive -> active), make sure the person exists as an
    # employee/user and is linked to this account. Only create one when the
    # account isn't already linked to an employee.
    if becoming_active and not acct["employee_id"]:
        name = (acct["full_name"] or acct["username"] or acct["email"] or "").strip()
        # Link to an existing person first (avoids duplicate employee records).
        match = _match_unlinked_employee(conn, acct["full_name"] or name, acct["email"])
        if match:
            conn.execute("UPDATE accounts SET employee_id=? WHERE id=?", (match, account_id))
            flash(f"Approved — linked to existing employee #{match}", "success")
        else:
            new_emp = str((conn.execute(
                "SELECT MAX(CAST(employee_id AS INTEGER)) FROM users").fetchone()[0] or 0) + 1)
            conn.execute(
                "INSERT INTO users (employee_id, name, is_active, email) VALUES (?,?,1,?)",
                (new_emp, name or new_emp, acct["email"]))
            conn.execute("UPDATE accounts SET employee_id=? WHERE id=?", (new_emp, account_id))
            flash(f"Approved — added as employee #{new_emp}", "success")

    conn.commit()
    conn.close()
    return redirect(url_for("accounts.accounts_list"))


@bp_accounts.route("/role/<int:account_id>", methods=["POST"])
@login_required
@role_required("admin")
def accounts_set_role(account_id):
    """Change an account's role — handy when approving a self-registered user."""
    role = request.form.get("role")
    if role not in ("admin", "manager", "viewer", "employee", "foreman"):
        flash("Invalid role", "danger")
        return redirect(url_for("accounts.accounts_list"))
    if session.get("account_id") == account_id and role != "admin":
        flash("You cannot remove your own admin role.", "danger")
        return redirect(url_for("accounts.accounts_list"))
    emp = (request.form.get("employee_id") or "").strip() or None
    conn = get_conn()
    conn.execute("UPDATE accounts SET role=?, employee_id=? WHERE id=?",
                 (role, emp, account_id))
    conn.commit()
    conn.close()
    flash("Role updated", "success")
    return redirect(url_for("accounts.accounts_list"))


@bp_accounts.route("/delete/<int:account_id>", methods=["POST"])
@login_required
@role_required("admin")
def accounts_delete(account_id):
    """Reject/remove an account (e.g. a bot registration)."""
    if session.get("account_id") == account_id:
        flash("Cannot delete your own account", "danger")
        return redirect(url_for("accounts.accounts_list"))
    conn = get_conn()
    conn.execute("DELETE FROM accounts WHERE id=?", (account_id,))
    conn.commit()
    conn.close()
    flash("Account removed", "success")
    return redirect(url_for("accounts.accounts_list"))


@bp_accounts.route("/edit/<int:account_id>", methods=["GET", "POST"])
@login_required
@role_required("admin")
def accounts_edit(account_id):
    """Edit an account's name and role. If the account is linked to an
    employee, the name change is mirrored to that employee record."""
    conn = get_conn()
    acct = conn.execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
    if not acct:
        conn.close()
        flash("Account not found", "danger")
        return redirect(url_for("accounts.accounts_list"))

    if request.method == "POST":
        first_name = (request.form.get("first_name") or "").strip()
        last_name  = (request.form.get("last_name") or "").strip()
        full_name  = (first_name + " " + last_name).strip()
        role = request.form.get("role")
        if role not in ("admin", "manager", "viewer", "employee", "foreman"):
            conn.close()
            flash("Invalid role", "danger")
            return redirect(url_for("accounts.accounts_edit", account_id=account_id))
        if session.get("account_id") == account_id and role != "admin":
            conn.close()
            flash("You cannot remove your own admin role.", "danger")
            return redirect(url_for("accounts.accounts_edit", account_id=account_id))

        conn.execute("UPDATE accounts SET role=?, full_name=? WHERE id=?",
                     (role, full_name or None, account_id))
        # Mirror shared fields (name, email) to the linked employee, if any.
        if acct["employee_id"]:
            if full_name:
                conn.execute("UPDATE users SET name=? WHERE employee_id=?",
                             (full_name, acct["employee_id"]))
            if acct["email"]:
                conn.execute(
                    "UPDATE users SET email=? WHERE employee_id=? AND (email IS NULL OR email='')",
                    (acct["email"], acct["employee_id"]))
        # If the account is now an attendance role but isn't linked to an
        # employee yet, create the employee record so it appears in Users.
        if role in ("employee", "foreman") and not acct["employee_id"]:
            name = full_name or acct["username"]
            new_emp = str((conn.execute(
                "SELECT MAX(CAST(employee_id AS INTEGER)) FROM users").fetchone()[0] or 0) + 1)
            conn.execute("INSERT INTO users (employee_id, name, is_active, email) VALUES (?,?,1,?)",
                         (new_emp, name, acct["email"]))
            conn.execute("UPDATE accounts SET employee_id=? WHERE id=?", (new_emp, account_id))
            flash(f"Updated — added as employee #{new_emp}", "success")
        else:
            flash("Account updated", "success")
        conn.commit()
        conn.close()
        return redirect(url_for("accounts.accounts_list"))

    conn.close()
    nm = (acct["full_name"] or "").strip()
    parts = nm.split(" ", 1)
    first_name = parts[0] if parts and parts[0] else ""
    last_name  = parts[1] if len(parts) > 1 else ""
    return render_template("accounts_edit.html", acct=acct,
                           first_name=first_name, last_name=last_name)
