from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.security import check_password_hash, generate_password_hash
from datetime import datetime, timedelta
from db import get_conn, get_setting
import logging
import os
import re
import secrets
import sqlite3

bp = Blueprint("auth", __name__, url_prefix="/auth")
log = logging.getLogger(__name__)

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

# Registration throttle (per IP) — separate window from login.
_reg_attempts: dict = {}
REG_MAX     = 5     # registrations allowed per IP per window
REG_WINDOW  = 60    # minutes

# ── Login throttling (in-memory; single-process app) ─────────────────────────
MAX_ATTEMPTS   = 5          # failures allowed per window
WINDOW_MINUTES = 15         # sliding window
_failures: dict = {}        # key -> [datetime, ...]


def _client_ip():
    """Real client IP: behind cloudflared everything arrives from localhost,
    so trust CF-Connecting-IP / X-Forwarded-For before remote_addr."""
    return (request.headers.get("CF-Connecting-IP")
            or (request.headers.get("X-Forwarded-For", "").split(",")[0].strip()
                or None)
            or request.remote_addr or "?")


def _prune(key, now):
    cutoff = now - timedelta(minutes=WINDOW_MINUTES)
    _failures[key] = [t for t in _failures.get(key, []) if t > cutoff]
    if not _failures[key]:
        _failures.pop(key, None)


def _is_locked(key, now):
    _prune(key, now)
    return len(_failures.get(key, [])) >= MAX_ATTEMPTS


def _record_failure(key, now):
    _failures.setdefault(key, []).append(now)


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        ip  = _client_ip()
        now = datetime.now()

        # Throttle by IP and by IP+username so one attacker can't burn
        # a shared office IP for everyone with a single username.
        for key in (f"ip:{ip}", f"acct:{ip}:{username.lower()}"):
            if _is_locked(key, now):
                log.warning(f"[AUTH] LOCKED OUT ip={ip} user={username!r}")
                flash(f"Too many failed attempts. Try again in {WINDOW_MINUTES} minutes.",
                      "danger")
                return render_template("login.html"), 429

        conn = get_conn()
        acct = conn.execute(
            "SELECT * FROM accounts WHERE username=? AND active=1", (username,)
        ).fetchone()
        conn.close()
        if not acct or not check_password_hash(acct["password_hash"], password):
            _record_failure(f"ip:{ip}", now)
            _record_failure(f"acct:{ip}:{username.lower()}", now)
            log.warning(f"[AUTH] FAILED login ip={ip} user={username!r}")
            flash("Invalid username or password", "danger")
            return render_template("login.html")

        # Success: clear this user's failure history for the IP
        _failures.pop(f"acct:{ip}:{username.lower()}", None)
        log.info(f"[AUTH] login ok ip={ip} user={username!r} role={acct['role']}")

        session.clear()
        lang = session.get("lang", "en")
        session["account_id"] = acct["id"]
        session["role"]       = acct["role"]
        session["username"]   = acct["username"]
        session["lang"]       = lang
        # Link to an employee record (for the holiday module / self-service)
        try:
            session["employee_id"] = acct["employee_id"]
        except (KeyError, IndexError):
            session["employee_id"] = None

        # Default-credential gate: any account still using the literal
        # default password must change it before doing anything else.
        if password == "admin":
            session["must_change_password"] = True
            flash("You are using the default password — set a new one to continue.",
                  "warning")
            return redirect(url_for("holidays.change_password"))

        # Employees land on their holiday page; staff on the dashboard
        if acct["role"] == "employee":
            return redirect(request.args.get("next") or url_for("holidays.my_holidays"))
        if acct["role"] == "foreman":
            return redirect(request.args.get("next") or url_for("gps.team_page"))
        return redirect(request.args.get("next") or url_for("dashboard.dashboard"))
    return render_template("login.html", registration_enabled=_registration_enabled())


def _registration_enabled() -> bool:
    return get_setting("registration_enabled", "1") in ("1", "true", "True", "on")


def _site_base() -> str:
    """Public base URL for links in emails. Prefer an explicit setting, else
    derive from the request Host (forwarded through cloudflared) over https."""
    base = (get_setting("site_url", "") or "").strip().rstrip("/")
    if base:
        return base
    host = request.headers.get("X-Forwarded-Host") or request.host
    return f"https://{host}"


def _reg_locked(ip, now):
    cutoff = now - timedelta(minutes=REG_WINDOW)
    _reg_attempts[ip] = [t for t in _reg_attempts.get(ip, []) if t > cutoff]
    return len(_reg_attempts.get(ip, [])) >= REG_MAX


@bp.route("/register", methods=["GET", "POST"])
def register():
    if not _registration_enabled():
        flash("Self-registration is currently disabled.", "danger")
        return redirect(url_for("auth.login"))

    if request.method == "POST":
        ip  = _client_ip()
        now = datetime.now()
        if _reg_locked(ip, now):
            flash("Too many registration attempts. Please try again later.", "danger")
            return render_template("register.html"), 429

        email    = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""
        confirm  = request.form.get("confirm") or ""

        # Validation
        if not EMAIL_RE.match(email):
            flash("Please enter a valid email address.", "danger")
            return render_template("register.html", email=email)
        if len(password) < 8:
            flash("Password must be at least 8 characters.", "danger")
            return render_template("register.html", email=email)
        if password != confirm:
            flash("Passwords do not match.", "danger")
            return render_template("register.html", email=email)

        _reg_attempts.setdefault(ip, []).append(now)
        token = secrets.token_urlsafe(32)

        conn = get_conn()
        try:
            conn.execute(
                "INSERT INTO accounts (username, password_hash, role, active, "
                "email, email_verified, verify_token, created_at) "
                "VALUES (?,?,?,?,?,?,?,?)",
                (email, generate_password_hash(password), "viewer", 0,
                 email, 0, token, now.strftime("%Y-%m-%d %H:%M:%S")))
            conn.commit()
        except sqlite3.IntegrityError:
            conn.close()
            # Do not reveal whether the email already exists — generic message.
            flash("If that email is new, your request has been received. "
                  "Check your inbox to verify it.", "success")
            return redirect(url_for("auth.login"))
        conn.close()

        log.info(f"[AUTH] registration ip={ip} email={email!r} (pending approval)")

        # Send verification / welcome email (best-effort).
        try:
            from services.mailer import send_email, build_branded_email
            verify_url = f"{_site_base()}{url_for('auth.verify', token=token)}"

            html, text, inline = build_branded_email(
                heading="Welcome! Please verify your email",
                paragraphs=[
                    f"An account was created for <b>{email}</b>.",
                    "Confirm your email address by clicking the button below.",
                ],
                cta_label="Verify my email",
                cta_url=verify_url,
                footer="After verifying, an administrator must approve your account "
                       "before you can sign in. You'll be notified once it's approved. "
                       "If you didn't request this, you can ignore this message.",
            )
            send_email(email, "Verify your account", html, text, inline_images=inline)

            # Notify the admin that an approval is waiting (best-effort).
            admin_to = get_setting("report_recipient", "") or get_setting("smtp_sender", "")
            if admin_to:
                a_html, a_text, a_inline = build_branded_email(
                    heading="New account awaiting approval",
                    paragraphs=[
                        f"<b>{email}</b> has registered and is waiting for your approval.",
                        "Open <b>Accounts</b> to approve, set a role, or reject the request.",
                    ],
                    cta_label="Review in Accounts",
                    cta_url=f"{_site_base()}{url_for('accounts.accounts_list')}",
                    footer="You're receiving this because you're an administrator.",
                )
                send_email(admin_to, "New account awaiting approval",
                           a_html, a_text, inline_images=a_inline)
        except Exception as e:
            log.error(f"[AUTH] registration email error: {e}")

        flash("Account created. Check your email to verify it — then an "
              "administrator will approve your access.", "success")
        return redirect(url_for("auth.login"))

    return render_template("register.html")


@bp.route("/verify/<token>")
def verify(token):
    if not token or len(token) < 10:
        flash("Invalid verification link.", "danger")
        return redirect(url_for("auth.login"))
    conn = get_conn()
    acct = conn.execute(
        "SELECT id, email_verified FROM accounts WHERE verify_token=?", (token,)
    ).fetchone()
    if not acct:
        conn.close()
        flash("This verification link is invalid or has already been used.", "danger")
        return redirect(url_for("auth.login"))
    conn.execute(
        "UPDATE accounts SET email_verified=1, verify_token=NULL WHERE id=?",
        (acct["id"],))
    conn.commit()
    conn.close()
    flash("Email verified. An administrator will review and approve your "
          "account shortly.", "success")
    return redirect(url_for("auth.login"))


@bp.route("/logout", methods=["GET", "POST"])
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
