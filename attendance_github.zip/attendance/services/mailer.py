"""
services/mailer.py — small reusable SMTP sender.

Reuses the same SMTP settings the weekly/daily reports use
(smtp_sender, smtp_host, smtp_port, smtp_pass), so there is one place
to configure email for the whole app.
"""
import os
import smtplib
import logging
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.application import MIMEApplication
from db import get_setting

log = logging.getLogger(__name__)


def smtp_configured() -> bool:
    """True when enough SMTP settings exist to actually send mail."""
    return bool(get_setting("smtp_sender", "") and get_setting("smtp_pass", ""))


def send_email(to_addr: str, subject: str, html_body: str, text_body: str = "",
               inline_images: dict = None, attachments: list = None) -> tuple:
    """
    Send one email. Returns (ok: bool, error: str|None).
    Never raises — callers can proceed even if mail is down.

    inline_images: optional {cid: filepath}. Each image is embedded so the HTML
    can reference it as <img src="cid:<cid>">, which displays reliably in Gmail
    (unlike base64 data URIs, which Gmail strips).
    attachments: optional list of (filename, bytes) to attach to the message.
    """
    smtp_sender = get_setting("smtp_sender", "")
    smtp_host   = get_setting("smtp_host",   "smtp.gmail.com")
    smtp_port   = int(get_setting("smtp_port", "587") or 587)
    smtp_pass   = get_setting("smtp_pass",   "")

    if not smtp_sender or not smtp_pass:
        return False, "SMTP not configured"
    if not to_addr:
        return False, "No recipient"

    alt = MIMEMultipart("alternative")
    if text_body:
        alt.attach(MIMEText(text_body, "plain"))
    alt.attach(MIMEText(html_body, "html"))

    # When embedding images, wrap the alternative part in a related container.
    valid_images = {cid: p for cid, p in (inline_images or {}).items()
                    if p and os.path.exists(p)}
    if valid_images:
        content = MIMEMultipart("related")
        content.attach(alt)
        for cid, path in valid_images.items():
            try:
                with open(path, "rb") as fh:
                    img = MIMEImage(fh.read())
                img.add_header("Content-ID", f"<{cid}>")
                img.add_header("Content-Disposition", "inline", filename=os.path.basename(path))
                content.attach(img)
            except Exception as e:
                log.warning(f"[MAIL] could not embed image {path}: {e}")
    else:
        content = alt

    # File attachments go in an outer mixed container.
    if attachments:
        msg = MIMEMultipart("mixed")
        msg.attach(content)
        for fname, blob in attachments:
            part = MIMEApplication(blob, Name=fname)
            part["Content-Disposition"] = f'attachment; filename="{fname}"'
            msg.attach(part)
    else:
        msg = content

    msg["From"]    = smtp_sender
    msg["To"]      = to_addr
    msg["Subject"] = subject

    def _send_once():
        # Port 465 uses implicit SSL; everything else uses STARTTLS.
        if smtp_port == 465:
            server = smtplib.SMTP_SSL(smtp_host, smtp_port, timeout=30)
        else:
            server = smtplib.SMTP(smtp_host, smtp_port, timeout=30)
            server.ehlo()
            server.starttls()
            server.ehlo()
        try:
            server.login(smtp_sender, smtp_pass)
            server.send_message(msg)
        finally:
            try:
                server.quit()
            except Exception:
                pass

    # Cellular links are slow to open the first socket, so a cold connect can
    # time out once and then succeed — retry a single time on timeout.
    last_err = None
    for attempt in (1, 2):
        try:
            _send_once()
            log.info(f"[MAIL] sent to {to_addr}: {subject!r}")
            return True, None
        except (smtplib.SMTPConnectError, TimeoutError, OSError) as e:
            last_err = e
            log.warning(f"[MAIL] attempt {attempt} to {to_addr} failed: {e}")
            continue
        except Exception as e:
            log.error(f"[MAIL] failed to {to_addr}: {e}")
            return False, str(e)
    log.error(f"[MAIL] failed to {to_addr} after retry: {last_err}")
    return False, str(last_err)


# ── Branded email template ──────────────────────────────────────────────────────

ACCENT = "#3B82F6"


def _logo_path():
    """Absolute path to the company logo PNG, or None."""
    try:
        from services.settings import UPLOAD_DIR, LOGO_NAME
        p = UPLOAD_DIR / LOGO_NAME
        return str(p) if p.exists() else None
    except Exception:
        return None


def _brand_assets():
    """(company_name, logo_<img>_html, inline_images_dict)."""
    company = "Attendance System"
    try:
        from services.settings import get_company_settings
        company = (get_company_settings().get("name") or company).strip() or company
    except Exception:
        pass
    logo = _logo_path()
    inline = {"logo": logo} if logo else {}
    logo_html = (
        f'<img src="cid:logo" alt="{company}" '
        f'style="max-height:56px;max-width:220px;display:block;margin:0 auto 10px;">'
        if logo else ""
    )
    return company, logo_html, inline


def branded_shell(heading: str, inner_html: str, footer_html: str = "",
                  max_width: int = 480):
    """
    Wrap arbitrary inner HTML (paragraphs, KPI cards, tables) in the branded
    card with the company logo + name. Returns (html, inline_images).
    """
    company, logo_html, inline = _brand_assets()
    heading_html = (
        f'<h1 style="margin:0 0 14px;font-size:20px;color:#111827;font-weight:700;">{heading}</h1>'
        if heading else ""
    )
    footer_block = (
        f'<tr><td style="padding:18px 32px 28px;border-top:1px solid #f0f1f3;">{footer_html}</td></tr>'
        if footer_html else ""
    )
    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f4f5f7;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f5f7;padding:24px 12px;">
    <tr><td align="center">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0"
             style="max-width:{max_width}px;background:#ffffff;border-radius:14px;overflow:hidden;
                    border:1px solid #e5e7eb;font-family:Arial,Helvetica,sans-serif;">
        <tr><td style="background:{ACCENT};height:6px;line-height:6px;font-size:6px;">&nbsp;</td></tr>
        <tr><td style="padding:28px 32px 8px;text-align:center;">
          {logo_html}
          <div style="font-size:17px;font-weight:700;color:#111827;">{company}</div>
        </td></tr>
        <tr><td style="padding:14px 32px 4px;">
          {heading_html}
          {inner_html}
        </td></tr>
        {footer_block}
      </table>
      <div style="max-width:{max_width}px;margin:14px auto 0;font-size:11px;color:#9CA3AF;text-align:center;">
        {company} · Sistema de Asistencia
      </div>
    </td></tr>
  </table>
</body></html>"""
    return html, inline


def build_branded_email(heading: str, paragraphs, cta_label: str = None,
                        cta_url: str = None, footer: str = None):
    """
    Build a polished, email-client-safe HTML message with the company logo
    and name. Returns (html, text, inline_images) ready for send_email().

    paragraphs: list of strings (HTML allowed) for the body.
    """
    body_html = "".join(
        f'<p style="margin:0 0 14px;font-size:15px;line-height:1.6;color:#374151;">{p}</p>'
        for p in paragraphs
    )
    if cta_label and cta_url:
        body_html += f"""
        <table role="presentation" cellpadding="0" cellspacing="0" style="margin:26px auto;">
          <tr><td align="center" bgcolor="{ACCENT}" style="border-radius:8px;">
            <a href="{cta_url}" target="_blank"
               style="display:inline-block;padding:13px 30px;font-size:15px;font-weight:600;
                      color:#ffffff;text-decoration:none;border-radius:8px;
                      font-family:Arial,Helvetica,sans-serif;">{cta_label}</a>
          </td></tr>
        </table>
        <p style="margin:0 0 6px;font-size:12px;color:#9CA3AF;text-align:center;">
          {cta_label}: <a href="{cta_url}" style="color:{ACCENT};">{cta_url}</a>
        </p>"""

    footer_html = (
        f'<p style="margin:0;font-size:12px;line-height:1.5;color:#9CA3AF;">{footer}</p>'
        if footer else ""
    )
    html, inline = branded_shell(heading, body_html, footer_html)

    import re as _re
    text_lines = [heading, ""]
    for p in paragraphs:
        text_lines.append(_re.sub("<[^>]+>", "", p))
    if cta_label and cta_url:
        text_lines += ["", f"{cta_label}: {cta_url}"]
    if footer:
        text_lines += ["", _re.sub("<[^>]+>", "", footer)]
    text = "\n".join(text_lines)

    return html, text, inline
