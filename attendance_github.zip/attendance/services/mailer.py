"""
services/mailer.py — small reusable SMTP sender.

Reuses the same SMTP settings the weekly/daily reports use
(smtp_sender, smtp_host, smtp_port, smtp_pass), so there is one place
to configure email for the whole app.
"""
import smtplib
import logging
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from db import get_setting

log = logging.getLogger(__name__)


def smtp_configured() -> bool:
    """True when enough SMTP settings exist to actually send mail."""
    return bool(get_setting("smtp_sender", "") and get_setting("smtp_pass", ""))


def send_email(to_addr: str, subject: str, html_body: str, text_body: str = "") -> tuple:
    """
    Send one email. Returns (ok: bool, error: str|None).
    Never raises — callers can proceed even if mail is down.
    """
    smtp_sender = get_setting("smtp_sender", "")
    smtp_host   = get_setting("smtp_host",   "smtp.gmail.com")
    smtp_port   = int(get_setting("smtp_port", "587") or 587)
    smtp_pass   = get_setting("smtp_pass",   "")

    if not smtp_sender or not smtp_pass:
        return False, "SMTP not configured"
    if not to_addr:
        return False, "No recipient"

    msg = MIMEMultipart("alternative")
    msg["From"]    = smtp_sender
    msg["To"]      = to_addr
    msg["Subject"] = subject
    if text_body:
        msg.attach(MIMEText(text_body, "plain"))
    msg.attach(MIMEText(html_body, "html"))

    try:
        server = smtplib.SMTP(smtp_host, smtp_port, timeout=20)
        server.starttls()
        server.login(smtp_sender, smtp_pass)
        server.send_message(msg)
        server.quit()
        log.info(f"[MAIL] sent to {to_addr}: {subject!r}")
        return True, None
    except Exception as e:
        log.error(f"[MAIL] failed to {to_addr}: {e}")
        return False, str(e)
