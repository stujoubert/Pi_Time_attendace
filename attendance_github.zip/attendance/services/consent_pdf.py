# -*- coding: utf-8 -*-
"""Render a signed consent receipt as a PDF (reportlab).

Returns the PDF bytes, or None if reportlab is not installed on this host — the
caller treats the receipt as best-effort so a missing library never blocks the
consent itself. Install on the Pi with:
    sudo pip3 install --break-system-packages reportlab
"""
import io
from services import consent_content as C


def build_consent_pdf(signature, username, emp_name, emp_id, version, ts, ip):
    try:
        from reportlab.lib.pagesizes import LETTER
        from reportlab.lib.units import cm
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
        from reportlab.lib import colors
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                        ListFlowable, ListItem, HRFlowable,
                                        Table, TableStyle)
    except Exception:
        return None

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=LETTER, title="Consentimiento",
                            leftMargin=2 * cm, rightMargin=2 * cm,
                            topMargin=1.8 * cm, bottomMargin=1.8 * cm)
    ss = getSampleStyleSheet()
    body = ParagraphStyle("body", parent=ss["Normal"], fontSize=9, leading=13,
                          alignment=TA_JUSTIFY, spaceAfter=6)
    head = ParagraphStyle("head", parent=ss["Normal"], fontSize=10.5, leading=14,
                          spaceBefore=8, spaceAfter=3, fontName="Helvetica-Bold")
    title = ParagraphStyle("title", parent=ss["Normal"], fontSize=15,
                           alignment=TA_CENTER, spaceAfter=4,
                           fontName="Helvetica-Bold")
    sub = ParagraphStyle("sub", parent=ss["Normal"], fontSize=8,
                         alignment=TA_CENTER, textColor=colors.grey, spaceAfter=10)

    story = [Paragraph(C.TITLE, title),
             Paragraph("Aviso de Privacidad — versión %s" % version, sub),
             Paragraph(C.INTRO, body)]
    for sec in C.SECTIONS:
        story.append(Paragraph(sec["h"], head))
        for blk in sec["blocks"]:
            if "p" in blk:
                story.append(Paragraph(blk["p"], body))
            elif "ul" in blk:
                items = [ListItem(Paragraph(x, body), leftIndent=6) for x in blk["ul"]]
                story.append(ListFlowable(items, bulletType="bullet",
                                          start="•", leftIndent=14))
    story.append(Spacer(1, 6))
    story.append(Paragraph(C.DECLARATION_TITLE,
                           ParagraphStyle("dh", parent=head, alignment=TA_CENTER)))
    story.append(Paragraph(C.DECLARATION, body))

    story.append(Spacer(1, 12))
    story.append(HRFlowable(width="100%", color=colors.grey, thickness=0.6))
    story.append(Spacer(1, 6))
    story.append(Paragraph("FIRMA ELECTRÓNICA",
                           ParagraphStyle("st", parent=body,
                                          fontName="Helvetica-Bold", spaceAfter=5)))
    emp_cell = emp_name or ""
    if emp_id:
        emp_cell = ("%s (ID %s)" % (emp_name or "", emp_id)).strip()
    rows = [
        ["Nombre / Firma:", signature or ""],
        ["Empleado:", emp_cell],
        ["Usuario:", username or ""],
        ["Versión del aviso:", version],
        ["Fecha y hora:", ts],
        ["IP de registro:", ip or ""],
    ]
    tbl = Table(rows, colWidths=[4.2 * cm, 11 * cm])
    tbl.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    story.append(tbl)
    story.append(Spacer(1, 10))
    story.append(Paragraph(
        "Este documento constituye la aceptación electrónica del aviso de "
        "privacidad por parte del titular, registrada por el sistema de control "
        "de asistencia en la fecha y hora indicadas.",
        ParagraphStyle("foot", parent=body, fontSize=7.5, textColor=colors.grey)))

    doc.build(story)
    return buf.getvalue()
