# -*- coding: utf-8 -*-
"""Render a signed consent receipt as a PDF (reportlab).

Returns the PDF bytes, or None if reportlab is not installed on this host — the
caller treats the receipt as best-effort so a missing library never blocks the
consent itself. Install on the Pi with:
    sudo pip3 install --break-system-packages reportlab
"""
import io
from services import consent_content as C


def build_consent_pdf(signature, username, emp_name, emp_id, version, ts, ip,
                      signature_img=None, title=None, blocks=None):
    try:
        from reportlab.lib.pagesizes import LETTER
        from reportlab.lib.units import cm
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
        from reportlab.lib import colors
        from reportlab.lib.utils import ImageReader
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                        ListFlowable, ListItem, HRFlowable,
                                        Table, TableStyle, Image as RLImage)
    except Exception:
        return None

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=LETTER, title="Consentimiento",
                            leftMargin=2 * cm, rightMargin=2 * cm,
                            topMargin=1.8 * cm, bottomMargin=1.8 * cm)
    ss = getSampleStyleSheet()
    body = ParagraphStyle("body", parent=ss["Normal"], fontSize=9, leading=13,
                          alignment=TA_JUSTIFY, spaceAfter=6)
    head = ParagraphStyle("head", parent=ss["Normal"], fontSize=10.5, leading=14,
                          spaceBefore=8, spaceAfter=3, fontName="Helvetica-Bold")
    title_style = ParagraphStyle("title", parent=ss["Normal"], fontSize=15,
                                 alignment=TA_CENTER, spaceAfter=4,
                                 fontName="Helvetica-Bold")
    sub = ParagraphStyle("sub", parent=ss["Normal"], fontSize=8,
                         alignment=TA_CENTER, textColor=colors.grey, spaceAfter=10)

    doc_title = title or C.TITLE
    doc_blocks = blocks if blocks is not None else C.get_consent_blocks()
    story = [Paragraph(doc_title, title_style),
             Paragraph("Aviso de Privacidad — versión %s" % version, sub)]
    for blk in doc_blocks:
        if "h" in blk:
            story.append(Paragraph(blk["h"], head))
        elif "p" in blk:
            story.append(Paragraph(blk["p"], body))
        elif "ul" in blk:
            items = [ListItem(Paragraph(x, body), leftIndent=6) for x in blk["ul"]]
            story.append(ListFlowable(items, bulletType="bullet",
                                      start="•", leftIndent=14))

    story.append(Spacer(1, 12))
    story.append(HRFlowable(width="100%", color=colors.grey, thickness=0.6))
    story.append(Spacer(1, 6))
    story.append(Paragraph("FIRMA ELECTRÓNICA",
                           ParagraphStyle("st", parent=body,
                                          fontName="Helvetica-Bold", spaceAfter=5)))
    # Hand-drawn (autograph) signature, if the user signed on screen.
    if signature_img and signature_img[:8] == b"\x89PNG\r\n\x1a\n":
        try:
            ir = ImageReader(io.BytesIO(signature_img))
            iw, ih = ir.getSize()
            max_w, max_h = 7 * cm, 2.4 * cm
            ratio = min(max_w / iw, max_h / ih)
            story.append(Paragraph("Firma autógrafa:",
                                   ParagraphStyle("sl", parent=body, fontSize=8,
                                                  textColor=colors.grey, spaceAfter=2)))
            story.append(RLImage(io.BytesIO(signature_img),
                                 width=iw * ratio, height=ih * ratio))
            story.append(HRFlowable(width=max_w, color=colors.black, thickness=0.5,
                                    spaceBefore=1, spaceAfter=8))
        except Exception:
            pass
    emp_cell = emp_name or ""
    if emp_id:
        emp_cell = ("%s (ID %s)" % (emp_name or "", emp_id)).strip()
    rows = [
        ["Nombre / Firma:", signature or ""],
        ["Empleado:", emp_cell],
        ["Usuario:", username or ""],
        ["Versión del aviso:", version],
        ["Fecha y hora:", ts],
        ["IP de registro:", ip or ""],
    ]
    tbl = Table(rows, colWidths=[4.2 * cm, 11 * cm])
    tbl.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    story.append(tbl)
    story.append(Spacer(1, 10))
    story.append(Paragraph(
        "Este documento constituye la aceptación electrónica del aviso de "
        "privacidad por parte del titular, registrada por el sistema de control "
        "de asistencia en la fecha y hora indicadas.",
        ParagraphStyle("foot", parent=body, fontSize=7.5, textColor=colors.grey)))

    doc.build(story)
    return buf.getvalue()
