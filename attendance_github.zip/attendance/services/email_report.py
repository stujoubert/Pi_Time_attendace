import smtplib
import io
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from datetime import datetime, timedelta
from db import get_setting
from services.reports import export_weekly_fifo

def send_weekly_report():
    smtp_sender = get_setting("smtp_sender", "")
    smtp_host   = get_setting("smtp_host",   "smtp.gmail.com")
    smtp_port   = int(get_setting("smtp_port", "587") or 587)
    smtp_pass   = get_setting("smtp_pass",   "")
    recipient   = get_setting("report_recipient", smtp_sender)

    if not smtp_sender or not smtp_pass or not recipient:
        return False

    today = datetime.now().date()
    week_start = today - timedelta(days=today.weekday())
    week_end   = week_start + timedelta(days=5)

    buf = export_weekly_fifo(week_start, week_end)

    msg = MIMEMultipart()
    msg["From"]    = smtp_sender
    msg["To"]      = recipient
    msg["Subject"] = f"Weekly Attendance {week_start} – {week_end}"
    msg.attach(MIMEText(f"Weekly attendance report attached.\nPeriod: {week_start} to {week_end}", "plain"))

    part = MIMEApplication(buf.read(), Name="weekly_attendance.xlsx")
    part["Content-Disposition"] = 'attachment; filename="weekly_attendance.xlsx"'
    msg.attach(part)

    server = smtplib.SMTP(smtp_host, smtp_port, timeout=20)
    server.starttls()
    server.login(smtp_sender, smtp_pass)
    server.send_message(msg)
    server.quit()
    return True


def _daily_stats(day):
    """Compute the summary + per-employee rows for a day's attendance."""
    from services.attendance import get_daily_attendance
    from db import get_conn

    att = get_daily_attendance(day)  # {emp: {name,in,out,hours,in_dt,flags,...}}

    conn = get_conn()
    try:
        total_active = conn.execute(
            "SELECT COUNT(*) FROM users WHERE is_active=1").fetchone()[0]
    except Exception:
        total_active = len(att)
    conn.close()

    work_start = (get_setting("work_start_time", "08:00") or "08:00")[:5]

    rows, present, late, incomplete, total_hours = [], 0, 0, 0, 0.0
    for emp, d in att.items():
        present += 1
        total_hours += d.get("hours") or 0
        in_str  = d.get("in") or "—"
        out_str = d.get("out") or "—"
        is_late = bool(d.get("in") and d["in"] > work_start)
        no_out  = ("no_out" in d.get("flags", [])) or not d.get("out")
        no_in   = ("no_in" in d.get("flags", [])) or not d.get("in")
        if is_late:
            late += 1
        if no_out or no_in:
            incomplete += 1
        if no_in:
            status, color = "Sin entrada", "#6b7280"
        elif no_out:
            status, color = "Sin salida", "#d97706"
        elif is_late:
            status, color = "Retardo", "#d97706"
        else:
            status, color = "A tiempo", "#16a34a"
        rows.append({"name": d.get("name") or emp, "in": in_str, "out": out_str,
                     "hours": d.get("hours") or 0, "status": status, "color": color,
                     "late": is_late})
    rows.sort(key=lambda r: (not r["late"], r["name"].lower()))
    absent = max(0, total_active - present)
    avg_hours = round(total_hours / present, 1) if present else 0
    return {
        "present": present, "absent": absent, "late": late,
        "incomplete": incomplete, "total": total_active,
        "avg_hours": avg_hours, "rows": rows,
    }


def _stat_card(number, label, color):
    return (
        f'<td align="center" width="25%" style="padding:6px;">'
        f'<div style="background:#f8fafc;border:1px solid #eef0f3;border-radius:10px;padding:12px 4px;">'
        f'<div style="font-size:26px;font-weight:700;color:{color};line-height:1.1;">{number}</div>'
        f'<div style="font-size:11px;color:#6b7280;margin-top:3px;">{label}</div>'
        f'</div></td>'
    )


def build_daily_report_html(day):
    """Returns (html, text, inline_images) for the daily report email."""
    from services.mailer import branded_shell

    s = _daily_stats(day)

    # KPI dashboard
    kpis = (
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:4px 0 8px;"><tr>'
        + _stat_card(s["present"], "Presentes", "#16a34a")
        + _stat_card(s["absent"],  "Ausentes",  "#dc2626")
        + _stat_card(s["late"],    "Retardos",  "#d97706")
        + _stat_card(f'{s["avg_hours"]}h', "Horas prom.", "#2563eb")
        + '</tr></table>'
    )

    # Detail table
    if s["rows"]:
        body = "".join(
            f'<tr>'
            f'<td style="padding:8px 6px;border-bottom:1px solid #f1f3f5;font-size:13px;color:#111827;">{r["name"]}</td>'
            f'<td style="padding:8px 6px;border-bottom:1px solid #f1f3f5;font-size:13px;text-align:center;font-family:monospace;">{r["in"]}</td>'
            f'<td style="padding:8px 6px;border-bottom:1px solid #f1f3f5;font-size:13px;text-align:center;font-family:monospace;">{r["out"]}</td>'
            f'<td style="padding:8px 6px;border-bottom:1px solid #f1f3f5;font-size:13px;text-align:center;">{r["hours"]}</td>'
            f'<td style="padding:8px 6px;border-bottom:1px solid #f1f3f5;text-align:center;">'
            f'<span style="font-size:11px;font-weight:600;color:{r["color"]};">{r["status"]}</span></td>'
            f'</tr>'
            for r in s["rows"]
        )
        table = (
            '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top:6px;border-collapse:collapse;">'
            '<tr style="background:#f8fafc;">'
            '<th align="left" style="padding:8px 6px;font-size:11px;color:#6b7280;text-transform:uppercase;">Empleado</th>'
            '<th style="padding:8px 6px;font-size:11px;color:#6b7280;text-transform:uppercase;">Entrada</th>'
            '<th style="padding:8px 6px;font-size:11px;color:#6b7280;text-transform:uppercase;">Salida</th>'
            '<th style="padding:8px 6px;font-size:11px;color:#6b7280;text-transform:uppercase;">Horas</th>'
            '<th style="padding:8px 6px;font-size:11px;color:#6b7280;text-transform:uppercase;">Estado</th>'
            '</tr>' + body + '</table>'
        )
    else:
        table = ('<p style="color:#6b7280;font-size:14px;text-align:center;padding:16px 0;">'
                 'No hubo registros de asistencia este día.</p>')

    intro = (f'<p style="margin:0 0 4px;font-size:14px;color:#6b7280;">Resumen del '
             f'<b style="color:#111827;">{day}</b> · {s["present"]} de {s["total"]} '
             f'empleados registraron asistencia.</p>')

    footer = ('<p style="margin:0;font-size:12px;color:#9CA3AF;">El detalle completo '
              'está en el archivo de Excel adjunto. Reporte automático enviado a las 09:00.</p>')

    inner = intro + kpis + table
    html, inline = branded_shell(f"Asistencia diaria — {day}", inner, footer, max_width=560)

    text = (f"Asistencia diaria {day}\n"
            f"Presentes: {s['present']}  Ausentes: {s['absent']}  "
            f"Retardos: {s['late']}  Horas prom: {s['avg_hours']}h\n"
            f"Detalle completo en el Excel adjunto.")
    return html, text, inline


def send_daily_report(target_date=None):
    """
    Email a one-day attendance report: a summary dashboard in the email body
    plus the full first-IN/last-OUT grid as an Excel attachment.

    Runs from the scheduler at 09:00; with no target_date it reports the
    PREVIOUS full day. Reuses the same SMTP settings/recipient as the weekly
    report, and only sends when enabled and SMTP is configured.
    """
    if get_setting("daily_report_enabled", "1") not in ("1", "true", "True", "on"):
        return False

    smtp_sender = get_setting("smtp_sender", "")
    smtp_pass   = get_setting("smtp_pass",   "")
    recipient   = get_setting("report_recipient", smtp_sender)
    if not smtp_sender or not smtp_pass or not recipient:
        return False

    day = target_date or (datetime.now().date() - timedelta(days=1))

    from services.mailer import send_email
    html, text, inline = build_daily_report_html(day)
    buf = export_weekly_fifo(day, day)  # single-day IN/OUT grid for the attachment
    fname = f"asistencia_{day}.xlsx"
    ok, err = send_email(recipient, f"Asistencia diaria {day}", html, text,
                         inline_images=inline, attachments=[(fname, buf.read())])
    return ok
