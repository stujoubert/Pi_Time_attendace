# -*- coding: utf-8 -*-
"""Single source of truth for the biometric/privacy consent text.

Both the on-screen consent page (templates/consent.html) and the signed PDF
receipt (services/consent_pdf.py) render from this module, so they can never
drift apart. Bump CONSENT_VERSION whenever the wording changes to re-prompt
everyone. List-item strings may contain simple <b>…</b> markup (understood by
both Jinja |safe and reportlab Paragraph)."""

CONSENT_VERSION = "2026-11"

TITLE = "CONSENTIMIENTO"

INTRO = ('G+TORUS S.A. DE C.V. (en adelante, el “Responsable”), con '
         'domicilio en Anillo Vial Fray Junípero Serra km 17, Edificio 20012, '
         'col. El Salitre, 76127 Santiago de Querétaro, Qro., es responsable '
         'del tratamiento, uso, almacenamiento y protección de sus datos '
         'personales y datos personales sensibles.')

SECTIONS = [
    {"h": "2. Datos Personales y Biométricos Recabados", "blocks": [
        {"p": "Para el cumplimiento de las finalidades descritas en el presente "
              "documento, el Responsable recabará, a través de la aplicación / "
              "plataforma digital de control de asistencia, los siguientes datos:"},
        {"ul": [
            "<b>Datos de identificación y laborales:</b> Nombre completo, número "
            "de empleado o usuario, puesto y área de adscripción.",
            "<b>Datos personales sensibles (Biométricos):</b> Captura fotográfica "
            "del rostro (selfie / reconocimiento facial) y los vectores o "
            "plantillas matemáticas derivados de sus rasgos faciales (geometría "
            "facial), así como los metadatos de geolocalización y marca de tiempo "
            "(fecha y hora) al momento de realizar cada registro.",
        ]},
    ]},
    {"h": "3. Finalidades del Tratamiento", "blocks": [
        {"p": "Sus datos biométricos y de identificación serán utilizados "
              "exclusivamente para las siguientes finalidades primarias, "
              "necesarias para la existencia, mantenimiento y cumplimiento de la "
              "relación jurídica y laboral:"},
        {"ul": [
            "Verificar y autenticar de manera inequívoca su identidad al momento "
            "de registrar sus entradas, salidas, descansos o turnos laborales.",
            "Llevar el control administrativo de asistencia, puntualidad y jornada "
            "laboral conforme a la Ley Federal del Trabajo y al Reglamento "
            "Interior de Trabajo.",
            "Garantizar la seguridad, integridad y veracidad de los registros de "
            "asistencia, evitando la suplantación de identidad.",
        ]},
        {"p": "Sus datos biométricos no serán utilizados para finalidades "
              "secundarias, mercadotécnicas, publicitarias ni distintas a las "
              "aquí señaladas."},
    ]},
    {"h": "4. Transferencias y Encargados del Tratamiento", "blocks": [
        {"p": "Sus datos personales y biométricos no serán transferidos a "
              "terceros, salvo en los casos expresamente previstos por el "
              "artículo 37 de la Ley Federal de Protección de Datos Personales en "
              "Posesión de los Particulares (requerimientos de autoridades "
              "laborales, fiscales o judiciales competentes)."},
        {"p": "El proveedor tecnológico de la aplicación actuará únicamente como "
              "Encargado del Tratamiento bajo las instrucciones y medidas de "
              "seguridad del Responsable, encontrándose obligado a guardar "
              "estricta confidencialidad y a no utilizar los datos para fines "
              "propios."},
    ]},
    {"h": "5. Medidas de Seguridad y Conservación", "blocks": [
        {"p": "El Responsable ha implementado medidas de seguridad "
              "administrativas, técnicas y físicas (cifrado de información y "
              "controles de acceso restringido) para proteger sus datos "
              "biométricos contra daño, pérdida, alteración, destrucción o el "
              "uso, acceso o tratamiento no autorizado. Los datos biométricos "
              "serán conservados únicamente durante la vigencia de la relación "
              "laboral y bloqueados/suprimidos conforme a los plazos legales "
              "aplicables una vez concluida esta."},
    ]},
    {"h": "6. Medios para Ejercer Derechos ARCO y Revocación del Consentimiento", "blocks": [
        {"p": "Usted tiene derecho a conocer qué datos personales tenemos de "
              "usted, para qué los utilizamos y las condiciones del uso que les "
              "damos (Acceso); solicitar la corrección de su información personal "
              "en caso de que esté desactualizada, sea inexacta o incompleta "
              "(Rectificación); que la eliminemos de nuestros registros o bases "
              "de datos cuando considere que la misma no está siendo utilizada "
              "adecuadamente (Cancelación); así como oponerse al uso de sus datos "
              "personales para fines específicos (Oposición), o revocar su "
              "consentimiento."},
        {"p": "Para ejercer cualquiera de estos derechos, deberá presentar su "
              "solicitud por escrito ante el Departamento de Recursos Humanos / "
              "Jurídico en el domicilio del Responsable, acompañando copia de su "
              "identificación oficial vigente."},
    ]},
    {"h": "7. Cambios al Aviso de Privacidad", "blocks": [
        {"p": "Cualquier modificación al presente documento será notificada a "
              "través de la propia aplicación o mediante avisos visibles en el "
              "centro de trabajo."},
    ]},
]

DECLARATION_TITLE = "DECLARACIÓN DE CONSENTIMIENTO EXPRESO"

DECLARATION = ("Manifiesto que he leído íntegramente el presente documento y "
               "otorgo mi consentimiento expreso a G+TORUS S.A. DE C.V. para que "
               "recabe, almacene y trate mis datos personales sensibles (datos "
               "biométricos consistentes en la captura fotográfica de mi rostro y "
               "reconocimiento facial) exclusivamente para el registro y control "
               "de mis entradas, salidas y asistencia laboral a través de la "
               "plataforma digital, en términos de los artículos 8 y 9 de la Ley "
               "Federal de Protección de Datos Personales en Posesión de los "
               "Particulares.")
