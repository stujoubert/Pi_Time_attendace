# -*- coding: utf-8 -*-
"""Biometric/privacy consent text — editable by admins, single source of truth.

The text lives in the `consent_text` setting (editable from the company admin
page) so each company can use its own name. The on-screen consent page and the
signed PDF receipt both render from the SAME parsed blocks, so they can never
drift apart.

Editing format (what the admin types in the textarea):
  * A line starting with "# "  is a heading.
  * A line starting with "- "  is a bullet.
  * Blank lines separate paragraphs; other lines are paragraph text.
  * Inside a line, <b>…</b> may be used for bold (understood by the page and
    the PDF).

Versioning: while the text is the untouched default, the version stays the
historical "2026-11" so already-signed staff are not re-prompted. As soon as an
admin saves a change, the version becomes a short fingerprint of the text, so
everyone is asked to sign the updated notice once."""

import hashlib
from db import get_setting

TITLE = "CONSENTIMIENTO"
_LEGACY_VERSION = "2026-11"

DEFAULT_TEXT = """\
G+TORUS S.A. DE C.V. (en adelante, el "Responsable"), con domicilio en Anillo Vial Fray Junípero Serra km 17, Edificio 20012, col. El Salitre, 76127 Santiago de Querétaro, Qro., es responsable del tratamiento, uso, almacenamiento y protección de sus datos personales y datos personales sensibles.

# 2. Datos Personales y Biométricos Recabados
Para el cumplimiento de las finalidades descritas en el presente documento, el Responsable recabará, a través de la aplicación / plataforma digital de control de asistencia, los siguientes datos:
- <b>Datos de identificación y laborales:</b> Nombre completo, número de empleado o usuario, puesto y área de adscripción.
- <b>Datos personales sensibles (Biométricos):</b> Captura fotográfica del rostro (selfie / reconocimiento facial) y los vectores o plantillas matemáticas derivados de sus rasgos faciales (geometría facial), así como los metadatos de geolocalización y marca de tiempo (fecha y hora) al momento de realizar cada registro.

# 3. Finalidades del Tratamiento
Sus datos biométricos y de identificación serán utilizados exclusivamente para las siguientes finalidades primarias, necesarias para la existencia, mantenimiento y cumplimiento de la relación jurídica y laboral:
- Verificar y autenticar de manera inequívoca su identidad al momento de registrar sus entradas, salidas, descansos o turnos laborales.
- Llevar el control administrativo de asistencia, puntualidad y jornada laboral conforme a la Ley Federal del Trabajo y al Reglamento Interior de Trabajo.
- Garantizar la seguridad, integridad y veracidad de los registros de asistencia, evitando la suplantación de identidad.
Sus datos biométricos no serán utilizados para finalidades secundarias, mercadotécnicas, publicitarias ni distintas a las aquí señaladas.

# 4. Transferencias y Encargados del Tratamiento
Sus datos personales y biométricos no serán transferidos a terceros, salvo en los casos expresamente previstos por el artículo 37 de la Ley Federal de Protección de Datos Personales en Posesión de los Particulares (requerimientos de autoridades laborales, fiscales o judiciales competentes).
El proveedor tecnológico de la aplicación actuará únicamente como Encargado del Tratamiento bajo las instrucciones y medidas de seguridad del Responsable, encontrándose obligado a guardar estricta confidencialidad y a no utilizar los datos para fines propios.

# 5. Medidas de Seguridad y Conservación
El Responsable ha implementado medidas de seguridad administrativas, técnicas y físicas (cifrado de información y controles de acceso restringido) para proteger sus datos biométricos contra daño, pérdida, alteración, destrucción o el uso, acceso o tratamiento no autorizado. Los datos biométricos serán conservados únicamente durante la vigencia de la relación laboral y bloqueados/suprimidos conforme a los plazos legales aplicables una vez concluida esta.

# 6. Medios para Ejercer Derechos ARCO y Revocación del Consentimiento
Usted tiene derecho a conocer qué datos personales tenemos de usted, para qué los utilizamos y las condiciones del uso que les damos (Acceso); solicitar la corrección de su información personal en caso de que esté desactualizada, sea inexacta o incompleta (Rectificación); que la eliminemos de nuestros registros o bases de datos cuando considere que la misma no está siendo utilizada adecuadamente (Cancelación); así como oponerse al uso de sus datos personales para fines específicos (Oposición), o revocar su consentimiento.
Para ejercer cualquiera de estos derechos, deberá presentar su solicitud por escrito ante el Departamento de Recursos Humanos / Jurídico en el domicilio del Responsable, acompañando copia de su identificación oficial vigente.

# 7. Cambios al Aviso de Privacidad
Cualquier modificación al presente documento será notificada a través de la propia aplicación o mediante avisos visibles en el centro de trabajo.

# DECLARACIÓN DE CONSENTIMIENTO EXPRESO
Manifiesto que he leído íntegramente el presente documento y otorgo mi consentimiento expreso a G+TORUS S.A. DE C.V. para que recabe, almacene y trate mis datos personales sensibles (datos biométricos consistentes en la captura fotográfica de mi rostro y reconocimiento facial) exclusivamente para el registro y control de mis entradas, salidas y asistencia laboral a través de la plataforma digital, en términos de los artículos 8 y 9 de la Ley Federal de Protección de Datos Personales en Posesión de los Particulares.
"""


def _saved_text():
    """The admin override, or None when unset (treats blank as unset)."""
    v = get_setting("consent_text", None)
    return v if (v and v.strip()) else None


def is_customized():
    return _saved_text() is not None


def get_consent_text():
    """The current editable consent body (admin override, else the default)."""
    return _saved_text() or DEFAULT_TEXT


def consent_version():
    """Stable while the text is the untouched default (keeps existing
    signatures valid); a content fingerprint once an admin edits it."""
    if _saved_text() is None:
        return _LEGACY_VERSION
    text = get_consent_text()
    return "c" + hashlib.sha256(text.encode("utf-8")).hexdigest()[:8]


def parse_blocks(text):
    """Parse the editing format into a flat list of blocks:
    {"h": str} heading, {"p": str} paragraph, {"ul": [str, ...]} bullet list."""
    blocks, para, ul = [], [], []

    def flush_para():
        if para:
            blocks.append({"p": " ".join(para).strip()})
            para.clear()

    def flush_ul():
        if ul:
            blocks.append({"ul": list(ul)})
            ul.clear()

    for raw in (text or "").splitlines():
        s = raw.strip()
        if s == "":
            flush_para(); flush_ul(); continue
        if s.startswith("# "):
            flush_para(); flush_ul(); blocks.append({"h": s[2:].strip()}); continue
        if s.startswith("- "):
            flush_para(); ul.append(s[2:].strip()); continue
        flush_ul(); para.append(s)
    flush_para(); flush_ul()
    return blocks


def get_consent_blocks():
    return parse_blocks(get_consent_text())
