import os
from pathlib import Path
from db import get_conn, get_setting, set_setting
from PIL import Image

# Always use absolute path relative to this file's location
_BASE_DIR  = Path(__file__).resolve().parent.parent
UPLOAD_DIR = _BASE_DIR / "static" / "uploads"
LOGO_NAME  = "company_logo.png"
ICON_SIZES = (192, 512)

def _first_existing(*names):
    """Return the /static/uploads/ URL of the first file that exists, else None."""
    for n in names:
        if (UPLOAD_DIR / n).exists():
            return f"/static/uploads/{n}"
    return None

def get_company_settings():
    conn = get_conn()
    rows = conn.execute("SELECT key,value FROM settings WHERE key LIKE 'company_%'").fetchall()
    conn.close()
    data = {r["key"]: r["value"] for r in rows}
    logo_path = UPLOAD_DIR / LOGO_NAME
    # PWA / home-screen icon: dedicated app icon → logo-derived → default.
    icon_url = _first_existing("app-icon-192.png", "icon-192.png") or "/static/icon-192.png"
    # Browser-tab favicon: dedicated favicon → app icon → logo-derived → default.
    favicon_url = _first_existing("favicon.png", "app-icon-192.png", "icon-192.png") or "/static/icon-192.png"
    return {
        "name":        data.get("company_name", ""),
        "rfc":         data.get("company_rfc", ""),
        "logo_url":    f"/static/uploads/{LOGO_NAME}" if logo_path.exists() else None,
        "icon_url":    icon_url,
        "favicon_url": favicon_url,
    }

def save_company_settings(name, rfc, logo_file=None, app_icon_file=None, favicon_file=None):
    """Save company name/RFC and (optionally) the logo, PWA app icon and favicon.

    Returns None on success, or an error code string ("logo_permission" |
    "logo_format") if an image couldn't be saved — the name/RFC are still saved
    so an image problem never loses the rest of the settings.
    """
    set_setting("company_name", name)
    set_setting("company_rfc", rfc)
    err = None
    for f, saver in ((logo_file, _save_logo),
                     (app_icon_file, _save_app_icon),
                     (favicon_file, _save_favicon)):
        if f and f.filename:
            try:
                saver(f)
            except PermissionError:
                return "logo_permission"
            except Exception:
                err = "logo_format"
    return err

def _save_logo(file_storage):
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    original = Image.open(file_storage.stream).convert("RGBA")

    # 1) Wordmark logo (height 80) for the app header and emails.
    wm = original
    if wm.height > 80:
        ratio = 80 / wm.height
        wm = wm.resize((max(1, int(wm.width * ratio)), 80), Image.LANCZOS)
    tmp = UPLOAD_DIR / (LOGO_NAME + ".tmp")
    wm.save(tmp, format="PNG", optimize=True)
    os.replace(tmp, UPLOAD_DIR / LOGO_NAME)

    # 2) Square PWA install icons generated from the full-resolution logo.
    #    Best-effort: the logo is already saved if this fails.
    try:
        _generate_app_icons(original)
    except Exception:
        pass


def _generate_app_icons(src, prefix="icon"):
    """Create square 192/512 app icons: the image centered on a white tile with
    a maskable safe-zone margin, so it looks right as an installed app icon.
    prefix="icon" = logo-derived fallback; prefix="app-icon" = dedicated icon."""
    src = src.convert("RGBA")
    for size in ICON_SIZES:
        canvas = Image.new("RGBA", (size, size), (255, 255, 255, 255))
        box = int(size * 0.72)  # leave margin for maskable crop
        ratio = min(box / src.width, box / src.height)
        w, h = max(1, int(src.width * ratio)), max(1, int(src.height * ratio))
        logo = src.resize((w, h), Image.LANCZOS)
        canvas.paste(logo, ((size - w) // 2, (size - h) // 2), logo)
        tmp = UPLOAD_DIR / f"{prefix}-{size}.png.tmp"
        canvas.convert("RGB").save(tmp, format="PNG", optimize=True)
        os.replace(tmp, UPLOAD_DIR / f"{prefix}-{size}.png")


def _save_app_icon(file_storage):
    """Save a dedicated PWA/home-screen icon (square 192/512), independent of
    the logo. Used when the user wants an app icon different from the wordmark."""
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    original = Image.open(file_storage.stream).convert("RGBA")
    _generate_app_icons(original, prefix="app-icon")


def _save_favicon(file_storage):
    """Save the browser-tab favicon (64x64 PNG). Transparency is preserved and
    the image is fit with a small margin so it stays crisp at tab size."""
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    src = Image.open(file_storage.stream).convert("RGBA")
    size = 64
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    box = int(size * 0.92)
    ratio = min(box / src.width, box / src.height)
    w, h = max(1, int(src.width * ratio)), max(1, int(src.height * ratio))
    ic = src.resize((w, h), Image.LANCZOS)
    canvas.paste(ic, ((size - w) // 2, (size - h) // 2), ic)
    tmp = UPLOAD_DIR / "favicon.png.tmp"
    canvas.save(tmp, format="PNG", optimize=True)
    os.replace(tmp, UPLOAD_DIR / "favicon.png")
