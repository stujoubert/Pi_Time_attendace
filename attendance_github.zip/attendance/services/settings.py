import os
from pathlib import Path
from db import get_conn, get_setting, set_setting
from PIL import Image

# Always use absolute path relative to this file's location
_BASE_DIR  = Path(__file__).resolve().parent.parent
UPLOAD_DIR = _BASE_DIR / "static" / "uploads"
LOGO_NAME  = "company_logo.png"
ICON_SIZES = (192, 512)

def get_company_settings():
    conn = get_conn()
    rows = conn.execute("SELECT key,value FROM settings WHERE key LIKE 'company_%'").fetchall()
    conn.close()
    data = {r["key"]: r["value"] for r in rows}
    logo_path = UPLOAD_DIR / LOGO_NAME
    icon_path = UPLOAD_DIR / "icon-192.png"
    return {
        "name":     data.get("company_name", ""),
        "rfc":      data.get("company_rfc", ""),
        "logo_url": f"/static/uploads/{LOGO_NAME}" if logo_path.exists() else None,
        # App-install icon: the custom one generated from the logo, else default.
        "icon_url": "/static/uploads/icon-192.png" if icon_path.exists() else "/static/icon-192.png",
    }

def save_company_settings(name, rfc, logo_file=None):
    """Save company name/RFC and (optionally) the logo.

    Returns None on success, or an error code string if the logo couldn't be
    saved ("logo_permission" | "logo_format") — the name/RFC are still saved so
    a logo problem never loses the rest of the settings.
    """
    set_setting("company_name", name)
    set_setting("company_rfc", rfc)
    if logo_file and logo_file.filename:
        try:
            _save_logo(logo_file)
        except PermissionError:
            return "logo_permission"
        except Exception:
            return "logo_format"
    return None

def _save_logo(file_storage):
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    original = Image.open(file_storage.stream).convert("RGBA")

    # 1) Wordmark logo (height 80) for the app header and emails.
    wm = original
    if wm.height > 80:
        ratio = 80 / wm.height
        wm = wm.resize((max(1, int(wm.width * ratio)), 80), Image.LANCZOS)
    tmp = UPLOAD_DIR / (LOGO_NAME + ".tmp")
    wm.save(tmp, format="PNG", optimize=True)
    os.replace(tmp, UPLOAD_DIR / LOGO_NAME)

    # 2) Square PWA install icons generated from the full-resolution logo.
    #    Best-effort: the logo is already saved if this fails.
    try:
        _generate_app_icons(original)
    except Exception:
        pass


def _generate_app_icons(src):
    """Create square 192/512 app icons: the logo centered on a white tile with
    a maskable safe-zone margin, so it looks right as an installed app icon."""
    src = src.convert("RGBA")
    for size in ICON_SIZES:
        canvas = Image.new("RGBA", (size, size), (255, 255, 255, 255))
        box = int(size * 0.72)  # leave margin for maskable crop
        ratio = min(box / src.width, box / src.height)
        w, h = max(1, int(src.width * ratio)), max(1, int(src.height * ratio))
        logo = src.resize((w, h), Image.LANCZOS)
        canvas.paste(logo, ((size - w) // 2, (size - h) // 2), logo)
        tmp = UPLOAD_DIR / f"icon-{size}.png.tmp"
        canvas.convert("RGB").save(tmp, format="PNG", optimize=True)
        os.replace(tmp, UPLOAD_DIR / f"icon-{size}.png")
